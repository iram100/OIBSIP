import java.util.Scanner;
public class ATMInterface {
    private UserDetails user;
    private TransactHistory hist;
    public ATMInterface(UserDetails user) {
        this.user = user;
        this.hist = new TransactHistory();
    }
    public void showMenu() {
        Scanner scnr = new Scanner(System.in);
        int option;
        do {
            System.out.println("Welcome " + user.getName() + " to the ATM");
            System.out.println("Menu:");
            System.out.println("1. Transaction History");
            System.out.println("2. Withdraw");
            System.out.println("3. Deposit");
            System.out.println("4. Transfer");
            System.out.println("5. Quit");
            System.out.print("Please select an option: ");
            option =scnr.nextInt();
            switch (option) {
                case 1:
                    hist.History();
                    break;
                case 2:
                    System.out.print("Please enter the amount to withdraw: ");
                    double withdrAmount = scnr.nextDouble();
                    if (user.withdraw(withdrAmount)) {
                        System.out.println("Withdrawal is successful!");
                        hist.addTransaction("Withdraw", withdrAmount);
                    } else {
                        System.out.println("Sorry! Insufficient balance.");
                    }
                    break;
                case 3:
                    System.out.print("Please enter the amount to deposit: ₹");
                    double depAmount = scnr.nextDouble();
                    user.deposit(depAmount);
                    System.out.println("Deposit is successful!");
                    hist.addTransaction("Deposit", depAmount);
                    break;
                case 4:
                    System.out.print("Pleas enter the amount to transfer: ₹");
                    double trAmount = scnr.nextDouble();
                    UserDetails dummyRec = new UserDetails("Recipient", "temporary", "0", 0);
                    if (user.transfer(dummyRec, trAmount)) {
                        System.out.println("Transfer successful!");
                        hist.addTransaction("Transfer", trAmount);
                    } else {
                        System.out.println("Sorry!Insufficient balance.");
                    }
                    break;
                case 5:
                    System.out.println("Thank you for using the ATM");
                    break;
                default:
                    System.out.println("Invalid option chosen.");
            }
        } while (option != 5);
    }
}
