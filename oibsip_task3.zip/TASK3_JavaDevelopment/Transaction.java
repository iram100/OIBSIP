public class Transaction {
    private String Otype;
    private double amount;

    public Transaction(String Otype, double amount) {
        this.Otype = Otype;
        this.amount = amount;
    }

    public String toString() {
        return Otype + ":" + amount;
    }
}
