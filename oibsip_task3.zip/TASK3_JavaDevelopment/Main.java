import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);
        UserDetails user1 = new UserDetails("Ira", "User1", "4321", 100000);
        System.out.println("Welcome to the ATM");
        System.out.print("please Enter your User ID: ");
        String inId = scnr.nextLine();
        System.out.print("Please enter your PIN: ");
        String inPin = scnr.nextLine();
        if (user1.login(inId, inPin)) {
            ATMInterface atm = new ATMInterface(user1);
            atm.showMenu();
        } else {
            System.out.println("Invalid credentials! Please check your details");
        }
    }
}
