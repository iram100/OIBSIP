import java.util.ArrayList;
public class TransactHistory {
    private ArrayList<Transaction> trans;
    public TransactHistory() {
        trans = new ArrayList<>();
    }
    public void addTransaction(String type, double amt) {
        trans.add(new Transaction(type, amt));
    }
    public void History() {
        if (trans.isEmpty()) {
            System.out.println("No transactions done");
        } else {
            System.out.println("Your Transaction History:");
            for (Transaction tr : trans) {
                System.out.println("- " + tr);
            }
        }
    }
}
