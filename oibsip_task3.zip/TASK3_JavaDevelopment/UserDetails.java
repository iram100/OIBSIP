public class UserDetails {
     String name;
     String user_Id;
     String pin;
     double balance;

    public UserDetails(String name, String user_Id, String pin, double balance) {
        this.name = name;
        this.user_Id = user_Id;
        this.pin = pin;
        this.balance = balance;
    }
    public boolean login(String id, String pin) {
        return this.user_Id.equals(id) && this.pin.equals(pin);
    }
    public String getName() {
        return name;
    }
    public double getBalance() {
        return balance;
    }
    public void deposit(double amt) {
        balance += amt;
    }
    public boolean withdraw(double amt) {
        if (amt <= balance) {
            balance -= amt;
            return true;
        }
        return false;
    }
    public boolean transfer(UserDetails rec, double amount) {
        if (amount <= balance) {
            balance -= amount;
            rec.deposit(amount);
            return true;
        }
        return false;
    }
}
